module.exports = function(docs) {
    return JSON.stringify(docs, null, 4);
}
