module.exports = function(docs) {
    // TODO
    return JSON.stringify(docs, null, 4);
}