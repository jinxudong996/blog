module.exports = {
    html: require('./html'),
    markdown: require('./markdown'),
    json: require('./json')
}