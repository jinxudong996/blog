const b=2;
const c=1;
const d=2;
function add(a,b){
    return a+b
}

add(c, d)
//# sourceMappingURL=./sourcemap.json
