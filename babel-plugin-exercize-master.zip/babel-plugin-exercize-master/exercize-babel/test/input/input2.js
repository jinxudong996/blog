function minus(a, b) {
    return a - b;
}

minus(3, 4);
