import { cc  as renamedCc } from './c';
 
export default b = 4;
