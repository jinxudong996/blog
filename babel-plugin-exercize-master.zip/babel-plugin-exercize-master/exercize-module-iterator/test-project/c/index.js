const cc = 5;

export {
    cc
};
