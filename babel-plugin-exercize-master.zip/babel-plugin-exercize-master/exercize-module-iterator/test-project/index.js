import { aa1, aa2 } from './a';

console.log(aa1);
