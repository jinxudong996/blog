import b from './b';

const aa1 = 1;
const aa2 = 2;

console.log(b);

export {
    aa1,
    aa2
}
